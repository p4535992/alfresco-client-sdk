/*
 *  Copyright (C) 2005-2016 Alfresco Software Limited.
 *
 *  This file is part of Alfresco Activiti Client.
 *
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package org.alfresco.client.api.process.enterprise.core.api;

import static org.alfresco.client.api.process.enterprise.ProcessServicesConstant.PROCESS_SERVICE_PATH;
import static org.alfresco.client.api.process.enterprise.common.constant.RequestConstant.FILE;

import org.alfresco.client.api.process.enterprise.common.model.representation.ResultList;
import org.alfresco.client.api.process.enterprise.core.model.idm.ResetPasswordRepresentation;
import org.alfresco.client.api.process.enterprise.core.model.idm.UserRepresentation;
import org.alfresco.client.api.process.enterprise.core.model.idm.request.ChangePasswordRepresentation;
import org.alfresco.client.api.process.enterprise.core.model.idm.request.UpdateProfileRepresentation;
import org.alfresco.client.api.process.enterprise.core.model.runtime.integration.dto.AlfrescoEndpointRepresentation;

import okhttp3.RequestBody;
import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.http.*;
import rx.Observable;

/**
 * Created by jpascal on 11/12/2014.
 */
public interface UserProfileAPI
{
    @GET(PROCESS_SERVICE_PATH + "/profile")
    Call<UserRepresentation> getProfileCall();

    @Headers({ "Content-type: application/json" })
    @POST(PROCESS_SERVICE_PATH + "/profile")
    Call<UserRepresentation> updateUserCall(@Body UpdateProfileRepresentation request);

    @GET(PROCESS_SERVICE_PATH + "/profile-picture")
    Call<Void> getProfilePictureCall();

    @Multipart
    @POST(PROCESS_SERVICE_PATH + "/profile-picture")
    Call<ResponseBody> uploadProfilePictureCall(@Part(FILE) RequestBody resource);

    @Headers({ "Content-type: application/json" })
    @POST(PROCESS_SERVICE_PATH + "/profile-password")
    Call<UserRepresentation> changePasswordCall(@Body ChangePasswordRepresentation request);

    @GET(PROCESS_SERVICE_PATH + "/profile/accounts/alfresco")
    Call<ResultList<AlfrescoEndpointRepresentation>> getRepositoriesCall();

    @Headers({ "Content-type: application/json" })
    @POST(PROCESS_SERVICE_PATH + "/idm/passwords")
    Call<Void> requestPasswordResetCall(@Body ResetPasswordRepresentation request);

    // ///////////////////////////////////////////////////////////////////////////
    // ///////////////////////////////////////////////////////////////////////////
    // ///////////////////////////////////////////////////////////////////////////
    // ///////////////////////////////////////////////////////////////////////////
    // ///////////////////////////////////////////////////////////////////////////
    // ///////////////////////////////////////////////////////////////////////////
    // ///////////////////////////////////////////////////////////////////////////
    // ///////////////////////////////////////////////////////////////////////////
    // ///////////////////////////////////////////////////////////////////////////
    // ///////////////////////////////////////////////////////////////////////////
    // ///////////////////////////////////////////////////////////////////////////
    // ///////////////////////////////////////////////////////////////////////////
    // ///////////////////////////////////////////////////////////////////////////
    // ///////////////////////////////////////////////////////////////////////////
    // ///////////////////////////////////////////////////////////////////////////
    // ///////////////////////////////////////////////////////////////////////////
    // ///////////////////////////////////////////////////////////////////////////
    // ///////////////////////////////////////////////////////////////////////////
    // ///////////////////////////////////////////////////////////////////////////
    // ///////////////////////////////////////////////////////////////////////////
    // ///////////////////////////////////////////////////////////////////////////
    // ///////////////////////////////////////////////////////////////////////////
    // ///////////////////////////////////////////////////////////////////////////
    // ///////////////////////////////////////////////////////////////////////////

    @GET(PROCESS_SERVICE_PATH + "/profile")
    Observable<UserRepresentation> getProfileObservable();

    @Headers({ "Content-type: application/json" })
    @POST(PROCESS_SERVICE_PATH + "/profile")
    Observable<UserRepresentation> updateUserObservable(@Body UpdateProfileRepresentation request);

    @GET(PROCESS_SERVICE_PATH + "/profile-picture")
    Observable<Void> getProfilePictureObservable();

    @Multipart
    @POST(PROCESS_SERVICE_PATH + "/profile-picture")
    Observable<ResponseBody> uploadProfilePictureObservable(@Part(FILE) RequestBody resource);

    @Headers({ "Content-type: application/json" })
    @POST(PROCESS_SERVICE_PATH + "/profile-password")
    Observable<UserRepresentation> changePasswordObservable(@Body ChangePasswordRepresentation request);

    @GET(PROCESS_SERVICE_PATH + "/profile/accounts/alfresco")
    Observable<ResultList<AlfrescoEndpointRepresentation>> getRepositoriesObservable();

    @Headers({ "Content-type: application/json" })
    @POST(PROCESS_SERVICE_PATH + "/idm/passwords")
    Observable<Void> requestPasswordResetObservable(@Body ResetPasswordRepresentation request);
}
