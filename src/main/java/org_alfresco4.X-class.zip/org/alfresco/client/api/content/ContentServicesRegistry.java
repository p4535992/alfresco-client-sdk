package org.alfresco.client.api.content;

import com.alfresco.client.api.authentication.AuthenticationAPI;
import com.alfresco.client.api.common.services.APIRegistry;
import com.alfresco.client.api.core.ActivitiesAPI;
import com.alfresco.client.api.core.CommentsAPI;
import com.alfresco.client.api.core.FavoritesAPI;
import com.alfresco.client.api.core.NetworksAPI;
import com.alfresco.client.api.core.NodesAPI;
import com.alfresco.client.api.core.PeopleAPI;
import com.alfresco.client.api.core.PreferencesAPI;
import com.alfresco.client.api.core.QueriesAPI;
import com.alfresco.client.api.core.RatingsAPI;
import com.alfresco.client.api.core.RenditionsAPI;
import com.alfresco.client.api.core.SharedLinksAPI;
import com.alfresco.client.api.core.SitesAPI;
import com.alfresco.client.api.core.TagsAPI;
import com.alfresco.client.api.core.TrashcanAPI;
import com.alfresco.client.api.core.VersionAPI;
import com.alfresco.client.api.discovery.DiscoveryAPI;
import com.alfresco.client.api.search.SearchAPI;

/**
 * Created by jpascal on 30/04/2017.
 * @deprecated
 */
public interface ContentServicesRegistry extends APIRegistry
{
    ActivitiesAPI getActivitiesAPI();

    CommentsAPI getCommentsAPI();

    FavoritesAPI getFavoritesAPI();

    NodesAPI getNodesAPI();

    PeopleAPI getPeopleAPI();

    RatingsAPI getRatingsAPI();

    SitesAPI getSitesAPI();

    TagsAPI getTagsAPI();

    QueriesAPI getQueriesAPI();

    RenditionsAPI getRenditionsAPI();

    SharedLinksAPI getSharedLinksAPI();

    TrashcanAPI getTrashcanAPI();

    VersionAPI getVersionAPI();

    DiscoveryAPI getDiscoveryAPI();

    AuthenticationAPI getAuthenticationAPI();

    SearchAPI getSearchAPI();

    NetworksAPI getNetworksAPI();

    PreferencesAPI getPreferencesAPI();
}
