/**
 * Copyright 2005-2017 Alfresco Software, Ltd. All rights reserved.
 * License rights for this program may be obtained from Alfresco Software, Ltd.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */
package org.alfresco.client.api.process.enterprise.editor.model;

import org.alfresco.client.api.process.enterprise.common.model.representation.AbstractRepresentation;

/**
 * @author Tijs Rademakers
 */
public class DataSourceConfigRepresentation extends AbstractRepresentation
{

    protected String jdbcUrl;

    protected String driverClass;

    protected String username;

    protected String password;

    public DataSourceConfigRepresentation()
    {
    }

    public String getJdbcUrl()
    {
        return jdbcUrl;
    }

    public void setJdbcUrl(String jdbcUrl)
    {
        this.jdbcUrl = jdbcUrl;
    }

    public String getDriverClass()
    {
        return driverClass;
    }

    public void setDriverClass(String driverClass)
    {
        this.driverClass = driverClass;
    }

    public String getUsername()
    {
        return username;
    }

    public void setUsername(String username)
    {
        this.username = username;
    }

    public String getPassword()
    {
        return password;
    }

    public void setPassword(String password)
    {
        this.password = password;
    }
}
