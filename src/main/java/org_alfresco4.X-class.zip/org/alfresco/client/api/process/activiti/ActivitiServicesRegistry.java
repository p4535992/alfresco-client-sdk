package org.alfresco.client.api.process.activiti;

import org.alfresco.client.api.process.activiti.core.api.*;

import com.alfresco.client.api.common.services.APIRegistry;

/**
 * Created by jpascal on 30/04/2017.
 */
public interface ActivitiServicesRegistry extends APIRegistry
{
    DatabaseTablesAPI getDatabaseTablesAPI();

    DeploymentsAPI getDeploymentsAPI();

    EngineAPI getEngineAPI();

    ExecutionsAPI getExecutionsAPI();

    FormsAPI getFormsAPI();

    GroupsAPI getGroupsAPI();

    HistoryAPI getHistoryAPI();

    JobsAPI getJobsAPI();

    ModelsAPI getModelsAPI();

    ProcessDefinitionsAPI getProcessDefinitionsAPI();

    ProcessInstancesAPI getProcessInstancesAPI();

    RuntimeAPI getRuntimeAPI();

    TasksAPI getTasksAPI();

    UsersAPI getUsersAPI();
}
