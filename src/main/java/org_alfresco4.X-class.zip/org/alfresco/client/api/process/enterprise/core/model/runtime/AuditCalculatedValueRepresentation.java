/**
 * Copyright 2005-2017 Alfresco Software, Ltd. All rights reserved.
 * License rights for this program may be obtained from Alfresco Software, Ltd.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */
package org.alfresco.client.api.process.enterprise.core.model.runtime;

/**
 * @author Vasile Dirla
 */
public class AuditCalculatedValueRepresentation
{

    protected String name;

    protected String value;

    public AuditCalculatedValueRepresentation()
    {

    }

    public AuditCalculatedValueRepresentation(String name, String value)
    {
        this.name = name;
        this.value = value;
    }

    public String getName()
    {
        return name;
    }

    public void setName(String name)
    {
        this.name = name;
    }

    public String getValue()
    {
        return value;
    }

    public void setValue(String value)
    {
        this.value = value;
    }

}
