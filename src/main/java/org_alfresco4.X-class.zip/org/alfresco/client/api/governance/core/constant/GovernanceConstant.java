package org.alfresco.client.api.governance.core.constant;

import com.alfresco.client.api.common.constant.APIConstant;

//import com.alfresco.client.api.common.services.APIConstant;

/**
 * Created by jpascal on 05/10/2016.
 */
public interface GovernanceConstant extends APIConstant
{
    String GS_PUBLIC_API_V1 = PREFIX_PUBLIC_API + "gs/versions/1";
}
