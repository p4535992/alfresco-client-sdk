package org.alfresco.client.api.process.activiti.core;

import com.alfresco.client.api.common.constant.APIConstant;

//import com.alfresco.client.api.common.services.APIConstant;

/**
 * Created by jpascal on 05/10/2016.
 */
public interface ActivitiConstant extends APIConstant
{
    String ACTIVITI_SERVICE_PATH = "service";
}
