package org.alfresco.client.api.governance;

import org.alfresco.client.api.governance.core.api.*;

import com.alfresco.client.api.common.services.APIRegistry;

/**
 * Created by jpascal on 30/04/2017.
 * @deprecated
 */
public interface GovernanceServicesRegistry extends APIRegistry
{
    GsSitesAPI getGsSitesAPI();

    FilePlansAPI getFilePlansAPI();

    RecordCategoriesAPI getRecordCategoriesAPI();

    RecordFoldersAPI getRecordFoldersAPI();

    RecordsAPI getRecordsAPI();

    UnfiledContainersAPI getUnfiledContainersAPI();

    UnfiledRecordFoldersAPI getUnfiledRecordFoldersAPI();

    TransferContainersAPI getTransferContainersAPI();

    TransfersAPI getTransfersAPI();

}
