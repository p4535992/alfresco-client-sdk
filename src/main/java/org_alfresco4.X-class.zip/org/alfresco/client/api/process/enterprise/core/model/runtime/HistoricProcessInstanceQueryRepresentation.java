/**
 * Copyright 2005-2017 Alfresco Software, Ltd. All rights reserved.
 * License rights for this program may be obtained from Alfresco Software, Ltd.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */
package org.alfresco.client.api.process.enterprise.core.model.runtime;

import java.util.Date;
import java.util.List;

/**
 * @author Tijs Rademakers
 */

public class HistoricProcessInstanceQueryRepresentation
{

    private String processInstanceId;

    private List<String> processInstanceIds;

    private String processBusinessKey;

    private String processDefinitionId;

    private String processDefinitionKey;

    private String superProcessInstanceId;

    private Boolean excludeSubprocesses;

    private Boolean finished;

    private String involvedUser;

    private Date finishedAfter;

    private Date finishedBefore;

    private Date startedAfter;

    private Date startedBefore;

    private String startedBy;

    private Boolean includeProcessVariables;

    private List<QueryVariable> variables;

    private String tenantId;

    private String tenantIdLike;

    private Boolean withoutTenantId;

    private Integer start;

    private Integer size;

    private String sort;

    private String order;

    public String getProcessInstanceId()
    {
        return processInstanceId;
    }

    public void setProcessInstanceId(String processInstanceId)
    {
        this.processInstanceId = processInstanceId;
    }

    public List<String> getProcessInstanceIds()
    {
        return processInstanceIds;
    }

    public void setProcessInstanceIds(List<String> processInstanceIds)
    {
        this.processInstanceIds = processInstanceIds;
    }

    public String getProcessBusinessKey()
    {
        return processBusinessKey;
    }

    public void setProcessBusinessKey(String processBusinessKey)
    {
        this.processBusinessKey = processBusinessKey;
    }

    public String getProcessDefinitionId()
    {
        return processDefinitionId;
    }

    public void setProcessDefinitionId(String processDefinitionId)
    {
        this.processDefinitionId = processDefinitionId;
    }

    public String getProcessDefinitionKey()
    {
        return processDefinitionKey;
    }

    public void setProcessDefinitionKey(String processDefinitionKey)
    {
        this.processDefinitionKey = processDefinitionKey;
    }

    public String getSuperProcessInstanceId()
    {
        return superProcessInstanceId;
    }

    public void setSuperProcessInstanceId(String superProcessInstanceId)
    {
        this.superProcessInstanceId = superProcessInstanceId;
    }

    public Boolean getExcludeSubprocesses()
    {
        return excludeSubprocesses;
    }

    public void setExcludeSubprocesses(Boolean excludeSubprocesses)
    {
        this.excludeSubprocesses = excludeSubprocesses;
    }

    public Boolean getFinished()
    {
        return finished;
    }

    public void setFinished(Boolean finished)
    {
        this.finished = finished;
    }

    public String getInvolvedUser()
    {
        return involvedUser;
    }

    public void setInvolvedUser(String involvedUser)
    {
        this.involvedUser = involvedUser;
    }

    public Date getFinishedAfter()
    {
        return finishedAfter;
    }

    public void setFinishedAfter(Date finishedAfter)
    {
        this.finishedAfter = finishedAfter;
    }

    public Date getFinishedBefore()
    {
        return finishedBefore;
    }

    public void setFinishedBefore(Date finishedBefore)
    {
        this.finishedBefore = finishedBefore;
    }

    public Date getStartedAfter()
    {
        return startedAfter;
    }

    public void setStartedAfter(Date startedAfter)
    {
        this.startedAfter = startedAfter;
    }

    public Date getStartedBefore()
    {
        return startedBefore;
    }

    public void setStartedBefore(Date startedBefore)
    {
        this.startedBefore = startedBefore;
    }

    public String getStartedBy()
    {
        return startedBy;
    }

    public void setStartedBy(String startedBy)
    {
        this.startedBy = startedBy;
    }

    public Boolean getIncludeProcessVariables()
    {
        return includeProcessVariables;
    }

    public void setIncludeProcessVariables(Boolean includeProcessVariables)
    {
        this.includeProcessVariables = includeProcessVariables;
    }

    public List<QueryVariable> getVariables()
    {
        return variables;
    }

    public void setVariables(List<QueryVariable> variables)
    {
        this.variables = variables;
    }

    public String getTenantId()
    {
        return tenantId;
    }

    public void setTenantId(String tenantId)
    {
        this.tenantId = tenantId;
    }

    public String getTenantIdLike()
    {
        return tenantIdLike;
    }

    public void setTenantIdLike(String tenantIdLike)
    {
        this.tenantIdLike = tenantIdLike;
    }

    public Boolean getWithoutTenantId()
    {
        return withoutTenantId;
    }

    public void setWithoutTenantId(Boolean withoutTenantId)
    {
        this.withoutTenantId = withoutTenantId;
    }

    public Integer getStart()
    {
        return start;
    }

    public void setStart(Integer start)
    {
        this.start = start;
    }

    public Integer getSize()
    {
        return size;
    }

    public void setSize(Integer size)
    {
        this.size = size;
    }

    public String getSort()
    {
        return sort;
    }

    public void setSort(String sort)
    {
        this.sort = sort;
    }

    public String getOrder()
    {
        return order;
    }

    public void setOrder(String order)
    {
        this.order = order;
    }

}
