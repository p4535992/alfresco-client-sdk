package org.alfresco.client.api.process.enterprise;

import com.alfresco.client.api.common.constant.APIConstant;

//import com.alfresco.client.api.common.services.APIConstant;

/**
 * Created by jpascal on 05/10/2016.
 */
public interface ProcessServicesConstant extends APIConstant
{
    String PROCESS_SERVICE_PATH = "api/enterprise";
}
