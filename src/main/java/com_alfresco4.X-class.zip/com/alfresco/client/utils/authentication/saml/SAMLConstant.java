package com.alfresco.client.utils.authentication.saml;

/**
 * Created by jpascal on 20/10/2016.
 */

public interface SAMLConstant
{

    String ALFRESCO_SAML_AUTHENTICATE_URL = "service/saml/-default-/rest-api/authenticate";

    String ALFRESCO_SAML_AUTHENTICATE_RESPONSE_URL = "service/saml/-default-/rest-api/authenticate-response";

    String ALFRESCO_SAML_INFO_URL = "service/saml/-default-/rest-api/enabled";
}
