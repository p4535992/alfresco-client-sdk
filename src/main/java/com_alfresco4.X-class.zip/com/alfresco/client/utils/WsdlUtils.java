package com.alfresco.client.utils;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.io.OutputStream;
import java.io.StringReader;
import java.io.StringWriter;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.net.Authenticator;
import java.net.MalformedURLException;
import java.net.PasswordAuthentication;
import java.net.URL;
import java.security.KeyManagementException;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSession;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;
import javax.security.auth.callback.Callback;
import javax.security.auth.callback.CallbackHandler;
import javax.security.auth.callback.UnsupportedCallbackException;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.bind.Unmarshaller;
import javax.xml.namespace.QName;
import javax.xml.soap.SOAPException;
import javax.xml.soap.SOAPMessage;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Source;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.stream.StreamResult;
import javax.xml.transform.stream.StreamSource;
import javax.xml.ws.BindingProvider;
import javax.xml.ws.handler.Handler;
import javax.xml.ws.handler.HandlerResolver;
import javax.xml.ws.handler.MessageContext;
import javax.xml.ws.handler.PortInfo;
import javax.xml.ws.handler.soap.SOAPHandler;
import javax.xml.ws.handler.soap.SOAPMessageContext;
import javax.xml.ws.soap.SOAPBinding;

import org.apache.cxf.configuration.jsse.TLSClientParameters;
import org.apache.cxf.configuration.security.AuthorizationPolicy;
import org.apache.cxf.endpoint.Client;
import org.apache.cxf.endpoint.Endpoint;
import org.apache.cxf.frontend.ClientProxy;
import org.apache.cxf.interceptor.LoggingInInterceptor;
import org.apache.cxf.interceptor.LoggingOutInterceptor;
import org.apache.cxf.jaxws.JaxWsProxyFactoryBean;
import org.apache.cxf.transport.http.HTTPConduit;
import org.apache.cxf.transports.http.configuration.HTTPClientPolicy;
import org.apache.cxf.ws.security.wss4j.WSS4JOutInterceptor;
import org.apache.wss4j.common.ext.WSPasswordCallback;
import org.apache.wss4j.dom.WSConstants;
import org.apache.wss4j.dom.handler.WSHandlerConstants;

public class WsdlUtils {
	
	 private final static org.slf4j.Logger logger = org.slf4j.LoggerFactory.getLogger(WsdlUtils.class);
	 
	 public static <T> T buildServerWsdl(String endpointWsdl,final String username,final String password,
	    		final Class<T> serviceClass,boolean ignoreSSLCertificate,
	    		boolean useMTOM,boolean forcePrintSOAP) 
	    	    throws NoSuchAlgorithmException, KeyManagementException, SOAPException, IOException{
		 return buildServerWsdl(endpointWsdl,username,password,
		    		serviceClass,ignoreSSLCertificate,false,
		    		null,useMTOM,forcePrintSOAP,
		    		null,null); 
	 }
	 
	 public static <T> T buildServerWsdl(String endpointWsdl,
	    		final Class<T> serviceClass,boolean ignoreSSLCertificate,
	    		boolean useMTOM,boolean forcePrintSOAP) 
	    	    throws NoSuchAlgorithmException, KeyManagementException, SOAPException, IOException{
		 return buildServerWsdl(endpointWsdl,null,null,
		    		serviceClass,ignoreSSLCertificate,false,
		    		null,useMTOM,forcePrintSOAP,
		    		null,null); 
	 }
	
	/**
     * Costruisci un server JAXB da un documento WSDL
     * NOTA: testato sule classi generati da cxf
	 * @param <T> è un interfaccia di classe di servizio xml generate da cxf o xjt 
     * @param endpointWsdl stringa url di endpoint del servizio wsdl puo essere sia il file che la risorsa online
     * @param username stringa username autenticazione
     * @param password stringa password autenticazione
     * @param serviceClass la classe di servizio generata da CXF
     * @param ignoreSSLCertificate se true disabilita la verifica certificati SSL
     * @param useAuthorizationBasic se true inserisce gli header per authentication basic
     * @param supplierheaders gli header aggiuntivi per la richiesta SOAP
     * @param useMTOM se true abiltia uso modalita MTOM
     * @param forcePrintSOAP se true scrive sulla console le richieste e risposte SOAP
     * @param SERVICE_NAME qname del servizio client
     * @param SERVICE_NAME_PORT qname del servizio server (getPort)
     * @return 
     * @throws NoSuchAlgorithmException
     * @throws KeyManagementException
     * @throws SOAPException 
     * @throws IOException 
     */
    public static <T> T buildServerWsdl(String endpointWsdl,final String username,final String password,
    		final Class<T> serviceClass,boolean ignoreSSLCertificate,boolean useAuthorizationBasic,
    		Map<String,String> supplierheaders,boolean useMTOM,boolean forcePrintSOAP,
    		javax.xml.namespace.QName SERVICE_NAME,javax.xml.namespace.QName SERVICE_NAME_PORT) 
    	    throws NoSuchAlgorithmException, KeyManagementException, SOAPException, IOException{

    	System.setProperty("org.apache.cxf.stax.allowInsecureParser", "true");
    	//Controllo wsdlurl
    	URL wsdlURL;
        java.io.File wsdlFile = new java.io.File(endpointWsdl);

        if (wsdlFile.exists()) {
            wsdlURL = wsdlFile.toURI().toURL();
        } else {
            wsdlURL = new URL(endpointWsdl);
        }
        logger.info("Buils server wsdl : <" + wsdlURL + "> ...");   	
        
    	T server = null;
    	try{	    	
    		JaxWsProxyFactoryBean factory = new JaxWsProxyFactoryBean();			
        	factory.setServiceClass(serviceClass);			
        	factory.setAddress(endpointWsdl);
        	//factory.setServiceClass(javax.xml.ws.Service.class);
        	//factory.setAddress("http://server.service.core.eng.it/");
        	//factory.setServiceBean(implementor);
        	//Abilita il loggin in ingresco ed uscita dei messaggi soap!
        	//TODO qui
        	if(forcePrintSOAP){
	        	factory.getInInterceptors().add(new LoggingInInterceptor(4*1024));
	        	factory.getOutInterceptors().add(new LoggingOutInterceptor(4*1024));
        	}
        	
//        	LoggingInInterceptor loggingInInterceptor = new LoggingInInterceptor();
//        	loggingInInterceptor.setPrettyLogging(true);
//        	LoggingOutInterceptor loggingOutInterceptor = new LoggingOutInterceptor();
//        	loggingOutInterceptor.setPrettyLogging(true);
//        	factory.getInInterceptors().add(loggingInInterceptor);
//        	factory.getOutInterceptors().add(loggingOutInterceptor);
	    	server = (T) factory.create();	
	    	//Client cl = ClientProxy.getClient(server);    	
	    	Client cl = ClientProxy.getClient(server);
	    	
	    	HTTPConduit httpConduit = (HTTPConduit) cl.getConduit();

	    	//disable ssl certificate handshake
	    	if(ignoreSSLCertificate){
	    		String targetAddr = httpConduit.getTarget().getAddress().getValue();
	    		if (targetAddr.toLowerCase().startsWith("https:")) {
	    			//TRUST ALL CERTIFICATE Create a trust manager that does not validate certificate chains
	    			TrustManager[] trustAllCerts = new TrustManager[] { new X509TrustManager() {			
	    				public java.security.cert.X509Certificate[] getAcceptedIssuers() {return new java.security.cert.X509Certificate[0];}
	    				public void checkClientTrusted(java.security.cert.X509Certificate[] certs, String authType) {}
	    				public void checkServerTrusted(java.security.cert.X509Certificate[] certs, String authType) {}
	    			} };
	    			//TRUST ALL HOST Ignore differences between given hostname and certificate hostname
	    		    HostnameVerifier hv = new HostnameVerifier(){
	    		    	public boolean verify(String hostname, SSLSession session) { return true; }
	    		    };
	    			//SSLContext sc = SSLContext.getInstance("SSL");
	    			//sc.init(null, trustAllCerts, new SecureRandom());
	    		    //hv.verify(wsdlURL.getHost(),sc.getClientSessionContext().getSession());
	    			TLSClientParameters tlsParams = new TLSClientParameters();
	    			tlsParams.setTrustManagers(trustAllCerts);//TRUST ALL CERTIFICATE    			
	    			tlsParams.setDisableCNCheck(true); //TRUST ALL CN
	    			tlsParams.setHostnameVerifier(hv);; //TRUST ALL HOST
	    			httpConduit.setTlsClientParameters(tlsParams);
	    		}
	    	}

	    	AuthorizationPolicy authorizationPolicy = httpConduit.getAuthorization();
	    	authorizationPolicy.setUserName(username);
	    	authorizationPolicy.setPassword(password);

	    	HTTPClientPolicy httpClientPolicy = new HTTPClientPolicy();
	    	httpClientPolicy.setConnectionTimeout(10000);//10sec
	    	httpClientPolicy.setReceiveTimeout(60000);
	    	
	    	//ATTENZIONE SE ARRIVA ERROR CON CODICE 415 sid eve settare un content type qui
	    	//httpClientPolicy.setContentType("application/soap+xml"); 
	    	httpClientPolicy.setContentType("text/xml"); 
	    	
	    	//Attenzione per errore  org.apache.cxf.transport.http.HTTPException: HTTP response '415: Unsupported Media Type'
	    	//qualcosa non va con encoding
	    	//httpClientPolicy.setAcceptEncoding("UTF-8");

	    	//httpClientPolicy.setConnection(ConnectionType.CLOSE);
	    	//httpClientPolicy.setMaxRetransmits(1);

	    	httpConduit.setClient(httpClientPolicy);   
	    	
	    	//=============================================================================================
	    	// Set up WS-Security Encryption, Reference: https://ws.apache.org/wss4j/using.html
	        Map<String, Object> outProps = new HashMap<String, Object>();
	        //props.put(WSHandlerConstants.USER, "testkey");
	        //props.put(WSHandlerConstants.ACTION, WSHandlerConstants.ENCRYPT);
	        //props.put(WSHandlerConstants.PASSWORD_TYPE, "PasswordText");
	        //props.put(WSHandlerConstants.ENC_PROP_FILE, "clientKeystore.properties");
	        //props.put(WSHandlerConstants.ENCRYPTION_PARTS, "{Content}{http://schemas.xmlsoap.org/soap/envelope/}Body");
	        //props.put(WSHandlerConstants.PW_CALLBACK_CLASS, ClientPasswordCallback.class.getName());
	        //props.put(WSHandlerConstants.ADD_INCLUSIVE_PREFIXES,false);
	        //props.put(ConfigurationConstants.EXPAND_XOP_INCLUDE_FOR_SIGNATURE, false);
	        
	        //inProps.put("expandXOPIncludeForSignature", false);
	        //inProps.put("expandXOPInclude", false);
	        //WSS4JOutInterceptor wss4jOut = new WSS4JOutInterceptor(inProps);

	        //ClientProxy.getClient(client).getOutInterceptors().add(wss4jOut);
	        //cl.getInInterceptors().add(wss4jOut);
	        //cl.getOutInterceptors();
	        //==============================================================================================
	    	
	        //org.apache.cxf.endpoint.Endpoint cxfEndpoint = cl.getEndpoint();
		    //Map<String, Object> outProps= new HashMap<String, Object>();
		    //outProps.put(WSHandlerConstants.ACTION,WSHandlerConstants.USERNAME_TOKEN + ' ' + WSHandlerConstants.TIMESTAMP);
		    //outProps.put(WSHandlerConstants.PASSWORD_TYPE, WSConstants.PW_TEXT);
		    //outProps.put(WSHandlerConstants.PW_CALLBACK_CLASS, ClientPasswordHandler.class.getName());
		    //outProps.put(WSHandlerConstants.USER, username);

		    //PhaseInterceptor<SoapMessage> wssOut = new WSS4JOutInterceptor(outProps);
		    //cxfEndpoint.getOutInterceptors().add(wssOut);
		    //cxfEndpoint.getOutInterceptors().add(new SAAJOutInterceptor());
	        
	        outProps.put(WSHandlerConstants.ACTION, WSHandlerConstants.USERNAME_TOKEN);
	        outProps.put(WSHandlerConstants.USER, username);
	        outProps.put(WSHandlerConstants.PASSWORD_TYPE, WSConstants.PW_DIGEST);
		 
			//Add this to your properties if you are using WSS4J < 2.0:			
		    //outProps.put(WSHandlerConstants.ADD_UT_ELEMENTS, WSConstants.NONCE_LN + " " + WSConstants.CREATED_LN);			
			//if using WSS4J >= 2.0 then it should be:
	        outProps.put(WSHandlerConstants.ADD_USERNAMETOKEN_NONCE, "true");
	        outProps.put(WSHandlerConstants.ADD_USERNAMETOKEN_CREATED, "true");
		    
	        outProps.put(WSHandlerConstants.MUST_UNDERSTAND, "false");
	        outProps.put(WSHandlerConstants.TTL_USERNAMETOKEN, "900");
	        outProps.put(WSHandlerConstants.TTL_FUTURE_USERNAMETOKEN, "900"); 
	        
	        ClientPasswordHandler handler = new ClientPasswordHandler(password);
		    outProps.put(WSHandlerConstants.PW_CALLBACK_REF, handler);
		    Endpoint cxfEndpoint = cl.getEndpoint();
		    
		    WSS4JOutInterceptor wssOut = new WSS4JOutInterceptor(outProps);
		    cxfEndpoint.getOutInterceptors().add(wssOut);
    	}catch(java.lang.NoSuchMethodError ne){
    		//GETISCE ERRORI PROBLEMI MAVEN
   		    //EVITA I PROBLEMI DERIVANTI DA COLLISIONI CON CXF E ALFRESCO (org.apache.ws.xmlschema.xml-schema-core e org.apache.ws.xmlschema.XmlSchema)
    		if(SERVICE_NAME != null && SERVICE_NAME_PORT != null){
        		 logger.warn("Problemi collisione dipendenze cxf si utilizza la libreria java standard");
		    	 //https://www.programcreek.com/java-api-examples/index.php?source_dir=jbossws-cxf-master/modules/testsuite/cxf-tests/src/test/java/org/jboss/test/ws/jaxws/cxf/jms/DeploymentTestServlet.java
		         javax.xml.ws.Service service = javax.xml.ws.Service.create(wsdlURL, SERVICE_NAME);    	         
//    	         java.lang.reflect.Field delegateField = javax.xml.ws.Service.class.getDeclaredField("delegate");
//    	         delegateField.setAccessible(true);
//    	         javax.xml.ws.spi.ServiceDelegate previousDelegate = (javax.xml.ws.spi.ServiceDelegate)delegateField.get(service);
//    	         if(!previousDelegate.getClass().getName().contains("cxf")) {
//    	        	 javax.xml.ws.spi.ServiceDelegate serviceDelegate = ((javax.xml.ws.spi.Provider) Class.forName("org.apache.cxf.jaxws.spi.ProviderImpl").newInstance())
//    	                 .createServiceDelegate(wsdlURL, SERVICE_NAME, service.getClass());
//    	             System.out.println("The " + service.getClass().getSimpleName() + " delegate is changed from " + "[" + previousDelegate + "] to [" + serviceDelegate +  "]");
//    	             delegateField.set(service, serviceDelegate);
//    	         }     	        		   	         
		    	  server = (T) service.getPort(SERVICE_NAME_PORT, serviceClass);    
    		
    		//DA TESTARE
    		//}else if(SERVICE_NAME != null && wsServiceClass != null){    			
    		//	 javax.xml.ws.Service service = buildServiceWsdl(endpointWsdl, SERVICE_NAME.getNamespaceURI(), SERVICE_NAME.getLocalPart(), wsServiceClass);
    		//	 
    		}else{
        		throw new SOAPException("Problemi collisione dipendenze cxf con alfresco (schema-core,XMlSchema) setta i servizi QNAME per utilizzare la java standard");
    		}
    		//disable ssl certificate handshake
		    if(ignoreSSLCertificate){
	    		String targetAddr = wsdlURL.toString();
	    		if (targetAddr.toLowerCase().startsWith("https:")) {
	    			//TRUST ALL CERTIFICATE Create a trust manager that does not validate certificate chains
	    			TrustManager[] trustAllCerts = new TrustManager[] { new X509TrustManager() {			
	    				public java.security.cert.X509Certificate[] getAcceptedIssuers() {return new java.security.cert.X509Certificate[0];}
	    				public void checkClientTrusted(java.security.cert.X509Certificate[] certs, String authType) {}
	    				public void checkServerTrusted(java.security.cert.X509Certificate[] certs, String authType) {}
	    			} };
	    			//TRUST ALL HOST Ignore differences between given hostname and certificate hostname
	    		    HostnameVerifier hv = new HostnameVerifier(){
	    		    	public boolean verify(String hostname, SSLSession session) { return true; }
	    		    };
	    			SSLContext sc = SSLContext.getInstance("SSL");
	    			sc.init(null, trustAllCerts, new SecureRandom());
	    		    //hv.verify(wsdlURL.getHost(),sc.getClientSessionContext().getSession());
	    		    HttpsURLConnection.setDefaultHostnameVerifier(hv);
	    		    HttpsURLConnection.setDefaultSSLSocketFactory(sc.getSocketFactory());
	    			
	    		}
		   }
    	}

    	// The BindingProvider interface provides access to the protocol binding and
    	// to the associated context objects for request and response message processing.
    	BindingProvider prov = (BindingProvider)server;
    	
    	SOAPBinding binding = (SOAPBinding) prov.getBinding();     	
    	//DISABILIAT/ABILITA MTOM
    	binding.setMTOMEnabled(useMTOM);   	
    	//Add handlers to the binding jaxb 
    	if(forcePrintSOAP){
	    	java.util.List<javax.xml.ws.handler.Handler> handlers = binding.getHandlerChain();
	    	handlers.add(new JaxWsLoggingHandler());
	    	binding.setHandlerChain(handlers);
    	}
        	
    	Map<String, Object> req_ctx = prov.getRequestContext();
    	req_ctx.put(BindingProvider.ENDPOINT_ADDRESS_PROPERTY, endpointWsdl);
    	//req_ctx.put("com.sun.xml.ws.developer.JAXWSProperties.CONNECT_TIMEOUT", timeout);
    	//req_ctx.put("com.sun.xml.ws.connect.timeout", timeout);
    	//req_ctx.put("com.sun.xml.ws.internal.connect.timeout", timeout);
    	//req_ctx.put("com.sun.xml.ws.request.timeout", timeout); 
    	//req_ctx.put("com.sun.xml.internal.ws.request.timeout", timeout);
		
    	Map<String, List<String>> headers = new HashMap<String, List<String>>();

    	if(username != null && password != null){	
    		headers.put("Username", Arrays.asList(username));
    		headers.put("Password", Arrays.asList(password));
    		//headers.put("Content-Type", Arrays.asList("text/xml")); //necessario specificare se si usa schema-core invece di XmlSchema

    		req_ctx.put(BindingProvider.USERNAME_PROPERTY, username);
    		req_ctx.put(BindingProvider.PASSWORD_PROPERTY, password);
    		    
    		//FILE TO ELEMENT
	        //InputStream clientPolicy = serviceClass.getResourceAsStream("webservices-client.xml");
    		// DocumentBuilderFactory builderFactory = DocumentBuilderFactory.newInstance();
    	    // builderFactory.setValidating(false);
    	    // builderFactory.setNamespaceAware(true);
    	    // builderFactory.setIgnoringElementContentWhitespace(true);
    	    // builderFactory.setIgnoringComments(true);
    	    // Element element = builderFactory.newDocumentBuilder().parse(clientPolicy).getDocumentElement();
	        //prov.put(ClientConstants.CLIENT_CONFIG, element);ù
    		
    		//Add some configuration 
    	 
    		//prov.put(ClientConstants.WSS_KEYSTORE_TYPE, "JKS");
    		//prov.put(ClientConstants.WSS_KEYSTORE_LOCATION, "D:\\default-keystore.jks");
    		//prov.put(ClientConstants.WSS_KEYSTORE_PASSWORD, "welcome1");
    		
    		//req_ctx.put("ws-security.store.bytes.in.attachment", "false");
    		//prov.getRequestContext().put("mtom-enabled", "false");
    		
    		//prov.getRequestContext().put("org.apache.cxf.http.no_io_exceptions", "true");
    		//prov.getRequestContext().put("org.apache.cxf.transport.no_io_exceptions", "true"); //for the latest cxf version
    		
    		if(supplierheaders !=null &&  supplierheaders.size() > 0){
    			prov.getRequestContext().putAll(supplierheaders);
    			for(Map.Entry<String, String> entry : supplierheaders.entrySet()){
    				headers.put(entry.getKey(), Arrays.asList(entry.getValue()));
    			}
    		}

    		Authenticator myAuth = new Authenticator() {
    			@Override
    			protected PasswordAuthentication getPasswordAuthentication() {
    				return new PasswordAuthentication(username, password.toCharArray());
    			}
    		};
    		Authenticator.setDefault(myAuth);		    		    
    	}

    	if(useAuthorizationBasic){
    		String authorization = new sun.misc.BASE64Encoder().encode((username+":"+password).getBytes());
    		headers.put("Authorization", Arrays.asList("Basic " + authorization));
    		req_ctx.put(MessageContext.HTTP_REQUEST_HEADERS, headers);
    		//MessageContext mctx = wsctx.getMessageContext();
    		Map<String, List<String>> http_headers = (HashMap<String, List<String>>) req_ctx.get(MessageContext.HTTP_REQUEST_HEADERS);
    		List list = (List) http_headers.get("Authorization");
    		if (list == null || list.size() == 0) {
    			throw new RuntimeException("Authentication failed! This WS needs BASIC Authentication!");
    		}

    		String userpass = (String) list.get(0);
    		userpass = userpass.substring(5);
    		byte[] buf = org.apache.commons.codec.binary.Base64.decodeBase64(userpass.getBytes());
    		String credentials = new String(buf);		  
    		String usernamex = null;
    		String passwordx = null;
    		int p = credentials.indexOf(":");
    		if (p > -1) {
    			usernamex = credentials.substring(0, p);
    			passwordx = credentials.substring(p+1);
    		}   
    		else {
    			throw new RuntimeException("There was an error while decoding the Authentication!");
    		}
    		// This should be changed to a DB / Ldap authentication check 
    		if (usernamex.equals(username) && passwordx.equals(password)) { 			 
    			logger.debug("============== Authentication Basic OK =============");
    		}
    		else {
    			throw new RuntimeException("Authentication failed! Wrong username / password!");
    		}
    	} 
    	  
    	return server;
	 		
    }
    
    /**
	 * Costruisci un servizio javax.xml.ws.Service per il servizio wsdl
	 */
	public static <T extends javax.xml.ws.Service> T buildServiceWsdl(String endpointWsdl,String namespaceUri,String localPart,Class<T> serviceClass) {
		try {
			URL wsdlUrl = new URL(endpointWsdl);
			javax.xml.namespace.QName SERVICE_NAME = new javax.xml.namespace.QName(namespaceUri, localPart);		

			Constructor<?> cons = serviceClass.getConstructor(URL.class,javax.xml.namespace.QName.class);
			@SuppressWarnings("unchecked")
			T service = (T) cons.newInstance(wsdlUrl,SERVICE_NAME);
			return service;
		} catch (MalformedURLException e) {			
			e.printStackTrace();
		} catch (NoSuchMethodException e) {
			e.printStackTrace();
		} catch (SecurityException e) {
			e.printStackTrace();
		} catch (InstantiationException e) {
			e.printStackTrace();
		} catch (IllegalAccessException e) {
			e.printStackTrace();
		} catch (java.lang.IllegalArgumentException e) {
			e.printStackTrace();
		} catch (InvocationTargetException e) {
			e.printStackTrace();
		}
		return null;

	}
	
	// =======================================================================
	// CONVERTER
	// =========================================================================
	
    public static <T> void toConsole(T jaxbObject) throws JAXBException{
    	JAXBContext jaxbContext = JAXBContext.newInstance(jaxbObject.getClass());
		Marshaller marshaller = jaxbContext.createMarshaller();
		marshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);
		StringWriter stringWriter = new StringWriter();
		marshaller.marshal(jaxbObject, System.out );
		logger.debug(stringWriter.toString());
    }
    
    public static <T> java.io.File toFile(T jaxbObject,java.io.File fileOutput) throws JAXBException{
    	JAXBContext jaxbContext = JAXBContext.newInstance(jaxbObject.getClass());
		Marshaller marshaller = jaxbContext.createMarshaller();
		marshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);
		marshaller.marshal(jaxbObject, fileOutput);
		return fileOutput;
    }
    
    public static <T> String toXML(T jaxbObject) throws JAXBException{
    	JAXBContext jaxbContext = JAXBContext.newInstance(jaxbObject.getClass());
		Marshaller marshaller = jaxbContext.createMarshaller();
		marshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);
		//marshaller.marshal(sip, System.out);
		StringWriter stringWriter = new StringWriter();
		marshaller.marshal(jaxbContext, stringWriter );
		return stringWriter.toString();
    }
    
    public static <T> T toXmlJavaObject(File xmlfile,Class<T> clazz) {
        try {
            JAXBContext context = JAXBContext.newInstance(clazz);
            Unmarshaller un = context.createUnmarshaller();
            T emp = (T) un.unmarshal(xmlfile);
            return emp;
        } catch (JAXBException e) {
            e.printStackTrace();
        }
        return null;
    }

	
	
	@SuppressWarnings("unchecked")
	public static <T> JAXBElement<T> toJaxbElement(javax.xml.namespace.QName qName,T objectJabx){
		 return new JAXBElement<T>(qName, (Class<T>) objectJabx.getClass(), null, objectJabx);
	}
	
	
	// ==============================================================================
	// PRIVATE CLASS
	// ===============================================================================
	
	
	private static class JaxWsHandlerResolver implements HandlerResolver {
		 
		private org.slf4j.Logger logger = org.slf4j.LoggerFactory.getLogger(JaxWsHandlerResolver.class);
	   
		@SuppressWarnings("rawtypes")
	    @Override
	    public List<Handler> getHandlerChain(PortInfo arg0) {
	        List<Handler> hchain = new ArrayList<Handler>();
	        hchain.add(new JaxWsLoggingHandler());
	        return hchain;
	    }
	 
	}
	
	private static class JaxWsLoggingHandler implements SOAPHandler<SOAPMessageContext> {
		 
		private org.slf4j.Logger logger = org.slf4j.LoggerFactory.getLogger(JaxWsLoggingHandler.class);
		   
		
	    @Override
	    public void close(MessageContext arg0) {
	    }
	 
	    @Override
	    public boolean handleFault(SOAPMessageContext arg0) {
	        SOAPMessage message = arg0.getMessage();
	        try {
	            message.writeTo(System.out);
	        } catch (SOAPException e) {
	            e.printStackTrace();
	        } catch (IOException e) {
	            e.printStackTrace();
	        }
	        return true;
	    }
	 
	    @Override
	    public boolean handleMessage(SOAPMessageContext arg0) {
	        SOAPMessage message = arg0.getMessage();
	        boolean isOutboundMessage = (Boolean) arg0.get(MessageContext.MESSAGE_OUTBOUND_PROPERTY);
	        System.out.println();
	        if (isOutboundMessage) {
	            logger.debug("OUTBOUND MESSAGE");
	        } else {
	            logger.debug("INBOUND MESSAGE");
	        }
	        try {
	        	//message.writeTo(System.out);
	        	try(OutputStream outStream = new ByteArrayOutputStream()) {
	                 message.writeTo(outStream);
	                 logger.debug(outStream.toString());
	            }
	        	/*
	        	TransformerFactory tff = TransformerFactory.newInstance();
	            Transformer tf = tff.newTransformer();        
	            tf.setOutputProperty(OutputKeys.INDENT, "yes");
	            tf.setOutputProperty("{http://xml.apache.org/xslt}indent-amount","2");
	        	Source source = message.getSOAPPart().getContent();
	        	ByteArrayOutputStream streamOut = new ByteArrayOutputStream();
	            StreamResult result = new StreamResult(streamOut);
	            tf.transform(source, result);
	            String preety = streamOut.toString();
	        	//String preety = prettyFormat(source);
	            System.out.println(preety);
	            */
	        } catch (Exception e) {
	            e.printStackTrace();
	        }         
	        return true;
	    }
	 
	    @Override
	    public Set<QName> getHeaders() {
	        return null;
	    }
	    
	    public String prettyFormat(SOAPMessage soapMessage, int indent) throws SOAPException {
	    	Source xmlInput = soapMessage.getSOAPPart().getContent();
	    	return prettyFormat(xmlInput,indent);
	    }
	    
	    public String prettyFormat(String input, int indent) {
	    	Source xmlInput = new StreamSource(new StringReader(input));
	    	return prettyFormat(xmlInput,indent);
	    }
	    
	    public String prettyFormat(Source xmlInput, int indent) {
	        try
	        {
	            //Source xmlInput = new StreamSource(new StringReader(input));
	        	
	            //StringWriter stringWriter = new StringWriter();            
	            ByteArrayOutputStream streamOut = new ByteArrayOutputStream();
	            StreamResult xmlOutput = new StreamResult(streamOut);
	            //StreamResult xmlOutput = new StreamResult(stringWriter);
	            
	            TransformerFactory transformerFactory = TransformerFactory.newInstance();
	            // This statement works with JDK 6
	            transformerFactory.setAttribute("indent-number", indent);
	             
	            Transformer transformer = transformerFactory.newTransformer();
	            transformer.setOutputProperty(OutputKeys.INDENT, "yes");
	            transformer.setOutputProperty("{http://xml.apache.org/xslt}indent-amount","2");
	              
	            transformer.transform(xmlInput, xmlOutput);
	            //return xmlOutput.getWriter().toString();            
	            String strMessage = streamOut.toString();
	            return strMessage;
	        }
	        catch (Throwable e)
	        {
	            // You'll come here if you are using JDK 1.5
	            // you are getting an the following exeption
	            // java.lang.IllegalArgumentException: Not supported: indent-number
	            // Use this code (Set the output property in transformer.
	            try
	            {
	                //Source xmlInput = new StreamSource(new StringReader(input));
	                StringWriter stringWriter = new StringWriter();
	                StreamResult xmlOutput = new StreamResult(stringWriter);
	                TransformerFactory transformerFactory = TransformerFactory.newInstance();
	                Transformer transformer = transformerFactory.newTransformer();
	                transformer.setOutputProperty(OutputKeys.INDENT, "yes");
	                transformer.setOutputProperty("{http://xml.apache.org/xslt}indent-amount", String.valueOf(indent));
	                transformer.transform(xmlInput, xmlOutput);
	                return xmlOutput.getWriter().toString();
	            }
	            catch(Throwable t)
	            {
	                return xmlInput.toString();
	            }
	        }
	    }
	 
	    public String prettyFormat(String input) {
	        return prettyFormat(input, 2);
	    }
	 
	}
	
	private static class ClientPasswordHandler implements CallbackHandler 
	{
		String password;
		
		public ClientPasswordHandler(String password) {
			this.password = password;
		}
		
		@Override
		public void handle(Callback[] callbacks) throws IOException, UnsupportedCallbackException {
			//VECCHIO CODICE
		    //WSPasswordCallback pc = (WSPasswordCallback) callbacks[0];
		    //pc.setPassword(password);	    
			
			//NUOVO CODICE
		    for (Callback callback : callbacks) {
	            if (callback instanceof WSPasswordCallback) {
	                WSPasswordCallback passwordCallback = (WSPasswordCallback) callback;
	                passwordCallback.setPassword(password);
	            } else {
	                throw new UnsupportedCallbackException(callback, "Unrecognized callback!");
	            }
	        }
	    }
	}
	
	public static HostnameVerifier setSystemTrustAllHost(){
		//TRUST ALL HOST Ignore differences between given hostname and certificate hostname
	    HostnameVerifier hv = new HostnameVerifier(){
	    	public boolean verify(String hostname, SSLSession session) { return true; }
	    };
	    //hv.verify(wsdlURL.getHost(),sc.getClientSessionContext().getSession());
	    //HttpsURLConnection.setDefaultHostnameVerifier(hv);
	    return hv;
	}
	
	public static SSLContext  setSystemTrustAllCertificateSSLContext()throws KeyManagementException, NoSuchAlgorithmException{
		return setSystemTrustAllCertificateSSLContext("SSL");
	}	
	
	public static SSLContext setSystemTrustAllCertificateSSLContext(String sslProtocol)throws KeyManagementException, NoSuchAlgorithmException{
		SSLContext sc = SSLContext.getInstance(sslProtocol);
		TrustManager[] trustAllCerts = setSystemTrustAllCertificateSSL(sslProtocol);
		sc.init(null, trustAllCerts, new SecureRandom());
		return sc;
	}
	
	public static TrustManager[] setSystemTrustAllCertificateSSL() throws KeyManagementException, NoSuchAlgorithmException{
		return setSystemTrustAllCertificateSSL("SSL");
	}
	
	public static TrustManager[] setSystemTrustAllCertificateSSL(String sslProtocol) throws KeyManagementException, NoSuchAlgorithmException{
		//TRUST ALL CERTIFICATE Create a trust manager that does not validate certificate chains
		TrustManager[] trustAllCerts = new TrustManager[] { 
				new X509TrustManager() {			
					public java.security.cert.X509Certificate[] getAcceptedIssuers() {return new java.security.cert.X509Certificate[0];}
					public void checkClientTrusted(java.security.cert.X509Certificate[] certs, String authType) {}
					public void checkServerTrusted(java.security.cert.X509Certificate[] certs, String authType) {}
				} 
		};
		//SSLContext sc = SSLContext.getInstance(sslProtocol);
		//sc.init(null, trustAllCerts, new SecureRandom());
		//HttpsURLConnection.setDefaultSSLSocketFactory(sc.getSocketFactory());
		return trustAllCerts;
	}
	
	public static void setSystemTrustAllCertificateAndHost() throws KeyManagementException, NoSuchAlgorithmException{		
		setSystemTrustAllCertificateSSL();
		setSystemTrustAllHost();
	}

}
