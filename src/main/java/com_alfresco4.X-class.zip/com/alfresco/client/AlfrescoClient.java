/*
 *   Copyright (C) 2005-2016 Alfresco Software Limited.
 *
 *   This file is part of Alfresco Java Client.
 *
 *   Licensed under the Apache License, Version 2.0 (the "License");
 *   you may not use this file except in compliance with the License.
 *   You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 *   Unless required by applicable law or agreed to in writing, software
 *   distributed under the License is distributed on an "AS IS" BASIS,
 *   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *   See the License for the specific language governing permissions and
 *   limitations under the License.
 */

package com.alfresco.client;

import java.util.ArrayList;
import java.util.HashMap;

import com.alfresco.client.api.common.services.ServicesClient;

import com.alfresco.client.api.authentication.AuthenticationAPI;
import com.alfresco.client.api.authentication.representation.TicketRepresentation;
import com.alfresco.client.api.authentication.representation.ValidTicketRepresentation;
import com.alfresco.client.api.common.deserializer.EntryDeserializer;
import com.alfresco.client.api.common.deserializer.PagingDeserializer;
import com.alfresco.client.api.common.representation.ResultPaging;
import com.alfresco.client.api.core.*;
import com.alfresco.client.api.core.model.deserializer.FavoriteEntryDeserializer;
import com.alfresco.client.api.core.model.representation.*;
import com.alfresco.client.api.discovery.DiscoveryAPI;
import com.alfresco.client.api.discovery.model.RepositoryInfoRepresentation;
import com.alfresco.client.api.search.SearchAPI;
import com.alfresco.client.api.search.deserializer.ResultSetPagingDeserializer;
import com.alfresco.client.api.search.model.ResultNodeRepresentation;
import com.alfresco.client.api.search.model.ResultSetRepresentation;
import com.alfresco.client.utils.ISO8601Utils;
import com.alfresco.swagger.api.SearchApi;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;

import okhttp3.OkHttpClient;
import retrofit2.Retrofit;
/**
 * @deprecated  valid only for Alfresco version minor of the 5.2,
 * if you use Alfresco 5.2 or major use instead the new yaml+swagger generated code on the new class {@link AlfrescoClientSwagger}
 * 
 */
public class AlfrescoClient extends AbstractClient<AlfrescoClient>
{
    protected static final Object LOCK = new Object();

    protected static AlfrescoClient mInstance;

    protected ActivitiesAPI activitiesAPI;

    protected CommentsAPI commentsAPI;

    protected DictionaryAPI dictionaryAPI;

    protected NodesAPI nodesAPI;

    protected PeopleAPI peopleAPI;

    protected QueriesAPI queriesAPI;

    protected RatingsAPI ratingsAPI;

    protected RenditionsAPI renditionsAPI;

    protected SharedLinksAPI sharedLinksAPI;

    protected SitesAPI sitesAPI;

    protected TagsAPI tagsAPI;

    protected TrashcanAPI trashcanAPI;

    protected FavoritesAPI favoritesAPI;

    protected DiscoveryAPI discoveryAPI;

    protected AuthenticationAPI authenticationAPI;

    protected SearchAPI searchAPI;

    // protected GroupsAPI groupsAPI;

    protected VersionAPI versionAPI;

    // ///////////////////////////////////////////////////////////////////////////
    // CONSTRUCTOR
    // ///////////////////////////////////////////////////////////////////////////
    public static AlfrescoClient getInstance()
    {
        synchronized (LOCK)
        {
            return mInstance;
        }
    }

    private AlfrescoClient(RestClient restClient, OkHttpClient okHttpClient)
    {
        super(restClient, okHttpClient);        
    }
    
    /**
     * @deprecated to clean
     */
    private AlfrescoClient(org.alfresco.client.api.content.CSClient csClient, 
    		org.alfresco.client.api.governance.GSClient gsClient, 
    		org.alfresco.client.api.process.PSClient psClient, 
    		org.alfresco.client.api.process.activiti.ActivitiClient aClient)
    {
    	super(null,null);
        this.csClient = csClient;
        this.gsClient = gsClient;
        this.psClient = psClient;
        this.aClient = aClient;  
    }

    // ///////////////////////////////////////////////////////////////////////////
    // API REGISTRY
    // ///////////////////////////////////////////////////////////////////////////
    public ActivitiesAPI getActivitiesAPI()
    {
        if (activitiesAPI == null)
        {
            activitiesAPI = getAPI(ActivitiesAPI.class);
        }
        return activitiesAPI;
    }

    public CommentsAPI getCommentsAPI()
    {
        if (commentsAPI == null)
        {
            commentsAPI = getAPI(CommentsAPI.class);
        }
        return commentsAPI;
    }

    public DictionaryAPI getDictionaryAPI()
    {
        if (dictionaryAPI == null)
        {
            dictionaryAPI = getAPI(DictionaryAPI.class);
        }
        return dictionaryAPI;
    }

    public FavoritesAPI getFavoritesAPI()
    {
        if (favoritesAPI == null)
        {
            favoritesAPI = getAPI(FavoritesAPI.class);
        }
        return favoritesAPI;
    }

    public NodesAPI getNodesAPI()
    {
        if (nodesAPI == null)
        {
            nodesAPI = getAPI(NodesAPI.class);
        }
        return nodesAPI;
    }

    public PeopleAPI getPeopleAPI()
    {
        if (peopleAPI == null)
        {
            peopleAPI = getAPI(PeopleAPI.class);
        }
        return peopleAPI;
    }

    public RatingsAPI getRatingsAPI()
    {
        if (ratingsAPI == null)
        {
            ratingsAPI = getAPI(RatingsAPI.class);
        }
        return ratingsAPI;
    }

    public SitesAPI getSitesAPI()
    {
        if (sitesAPI == null)
        {
            sitesAPI = getAPI(SitesAPI.class);
        }
        return sitesAPI;
    }

    public TagsAPI getTagsAPI()
    {
        if (tagsAPI == null)
        {
            tagsAPI = getAPI(TagsAPI.class);
        }
        return tagsAPI;
    }

    public QueriesAPI getQueriesAPI()
    {
        if (queriesAPI == null)
        {
            queriesAPI = getAPI(QueriesAPI.class);
        }
        return queriesAPI;
    }

    public RenditionsAPI getRenditionsAPI()
    {
        if (renditionsAPI == null)
        {
            renditionsAPI = getAPI(RenditionsAPI.class);
        }
        return renditionsAPI;
    }

    public SharedLinksAPI getSharedLinksAPI()
    {
        if (sharedLinksAPI == null)
        {
            sharedLinksAPI = getAPI(SharedLinksAPI.class);
        }
        return sharedLinksAPI;
    }

    public TrashcanAPI getTrashcanAPI()
    {
        if (trashcanAPI == null)
        {
            trashcanAPI = getAPI(TrashcanAPI.class);
        }
        return trashcanAPI;
    }

    public DiscoveryAPI getDiscoveryAPI()
    {
        if (discoveryAPI == null)
        {
            discoveryAPI = getAPI(DiscoveryAPI.class);
        }
        return discoveryAPI;
    }

    public AuthenticationAPI getAuthenticationAPI()
    {
        if (authenticationAPI == null)
        {
            authenticationAPI = getAPI(AuthenticationAPI.class);
        }
        return authenticationAPI;
    }

    public SearchAPI getSearchAPI()
    {
        if (searchAPI == null)
        {
            searchAPI = getAPI(SearchAPI.class);
        }
        return searchAPI;
    }
    
    // =============================================================================
    // SWAGGER SERVICE 
    // =============================================================================
   
//    public com.alfresco.swagger.api.SearchApi getSearchAPISwagger()
//    {
//    	this.apiClientSwagger.getAdapterBuilder().baseUrl(this.restClient.endpointSearchApi);        
//    	return apiClientSwagger.createService(com.alfresco.swagger.api.SearchApi.class);
//    }
//    
//    public com.alfresco.swagger.api.ActivitiesApi getActivitiesAPISwagger()
//    {
//    	this.apiClientSwagger.getAdapterBuilder().baseUrl(this.restClient.endpointCoreApi);        
//    	return apiClientSwagger.createService(com.alfresco.swagger.api.ActivitiesApi.class);
//    }


    // Not implemented
    /*
     * public GroupsAPI getGroupsAPI() { if (groupsAPI == null) { groupsAPI =
     * getAPI(GroupsAPI.class); } return groupsAPI; }
     */

    public VersionAPI getVersionAPI()
    {
        if (versionAPI == null)
        {
            versionAPI = getAPI(VersionAPI.class);
        }
        return versionAPI;
    }

    // ///////////////////////////////////////////////////////////////////////////
    // AUTHENTICATION
    // ///////////////////////////////////////////////////////////////////////////
    public void setTicket(String ticket)
    {

        OkHttpClient.Builder builder = getOkHttpClient().newBuilder();

        // Remove old interceptor
        int index = 0;
        for (int i = 0; i < builder.interceptors().size(); i++)
        {
            if (builder.interceptors().get(i) instanceof BasicAuthInterceptor
                    || builder.interceptors().get(i) instanceof TicketInterceptor)
            {
                index = i;
            }
        }

        builder.interceptors().remove(index);
        builder.interceptors().add(new TicketInterceptor(ticket));
        okHttpClient = builder.build();
    }

    // ///////////////////////////////////////////////////////////////////////////
    // BUILDER
    // ///////////////////////////////////////////////////////////////////////////
    public static class Builder extends AbstractClient.Builder<AlfrescoClient>
    {

        @Override
        public String getUSerAgent()
        {
            return "Alfresco-ECM-Client/" + Version.SDK;
        }

        @Override
        public AlfrescoClient create(RestClient restClient, OkHttpClient okHttpClient)
        {
            return new AlfrescoClient(new RestClient(endpoint, retrofit, username), okHttpClient);
        }

        @Override
        public GsonBuilder getDefaultGsonBuilder()
        {
            return Utils.getDefaultGsonBuilder();
        }
        
        // ///////////////////////////////////////////////////////////////////////////
        // MEMBERS
        // ///////////////////////////////////////////////////////////////////////////
        /**
         * @deprecated to clean
         */
        protected HashMap<ServicesEnum, ServicesClient.Builder> builderHashMap = new HashMap<>(4);
        /**
         * @deprecated to clean
         */
        protected HashMap<ServicesEnum, String> endpointHashMap = new HashMap<>(4);
        /**
         * @deprecated to clean
         */
        protected ArrayList<ServicesEnum> services = new ArrayList<>(4);
        
        //protected String endpoint, username, password;
        /**
         * @deprecated to clean
         */
        protected String ticket, token;

        // ///////////////////////////////////////////////////////////////////////////
        // PUBLIC METHODS
        // ///////////////////////////////////////////////////////////////////////////
        /**
         * @deprecated to clean
         */
        public Builder connectTo(String endpoint)
        {
            this.endpoint = endpoint;
            return this;
        }
        /**
         * @deprecated to clean
         */
        public Builder connectTo(String endpoint, ServicesEnum serviceId)
        {
            endpointHashMap.put(serviceId, endpoint);
            return this;
        }
        /**
         * @deprecated to clean
         */
        public Builder addService(ServicesEnum serviceId)
        {
            services.add(serviceId);
            return this;
        }

        /**
         * @deprecated to clean
         */
        public Builder addServiceClientBuilder(ServicesClient.Builder builder)
        {
            if (builder instanceof org.alfresco.client.api.content.CSClient.Builder)
            {
                builderHashMap.put(ServicesEnum.CONTENT_SERVICES, builder);
            }
            else if (builder instanceof org.alfresco.client.api.governance.GSClient.Builder)
            {
                builderHashMap.put(ServicesEnum.GOVERNANCE_SERVICES, builder);
            }
            else if (builder instanceof org.alfresco.client.api.process.PSClient.Builder)
            {
                builderHashMap.put(ServicesEnum.PROCESS_SERVICES, builder);
            }
            return this;
        }
        /**
         * @deprecated to clean
         */
        public Builder withTicket(String ticket)
        {
            this.ticket = ticket;
            return this;
        }
        /**
         * @deprecated to clean
         */
        public Builder withToken(String token)
        {
            this.token = token;
            return this;
        }
        /**
         * @deprecated to clean
         */
        public Builder withUser(String username, String password)
        {
            this.username = username;
            this.password = password;
            return this;
        }
        
     // ///////////////////////////////////////////////////////////////////////////
        // GENERATE ALFRESCO CLIENT
        // ///////////////////////////////////////////////////////////////////////////
        /** @deprecated to clean */
	public AlfrescoClient buildOLD()
        {
            org.alfresco.client.api.content.CSClient.Builder csClient;
            org.alfresco.client.api.process.PSClient.Builder psClient;
            org.alfresco.client.api.governance.GSClient.Builder gsClient;
            org.alfresco.client.api.process.activiti.ActivitiClient.Builder aClient;

            // Create Content Services
            csClient = (org.alfresco.client.api.content.CSClient.Builder) generate(ServicesEnum.CONTENT_SERVICES);
            psClient = (org.alfresco.client.api.process.PSClient.Builder) generate(ServicesEnum.PROCESS_SERVICES);
            gsClient = (org.alfresco.client.api.governance.GSClient.Builder) generate(ServicesEnum.GOVERNANCE_SERVICES);
            aClient = (org.alfresco.client.api.process.activiti.ActivitiClient.Builder) generate(ServicesEnum.ACTIVITI);

            return new AlfrescoClient((csClient != null) ? csClient.build() : null,
                    (gsClient != null) ? gsClient.build() : null, (psClient != null) ? psClient.build() : null,
                    (aClient != null) ? aClient.build() : null);
        }

        /** @deprecated to clean */
        public ServicesClient.Builder generate(ServicesEnum servicesEnum)
        {
            ServicesClient.Builder clientBuilder = null;
            String localEndpoint = endpoint;

            // Create Content Services
            if (builderHashMap.containsKey(servicesEnum))
            {
                return builderHashMap.get(servicesEnum);
            }
            else if (endpointHashMap.containsKey(servicesEnum))
            {
                localEndpoint = endpointHashMap.get(servicesEnum);
            }
            else
            {
                return null;
            }

            switch (servicesEnum)
            {
                case CONTENT_SERVICES:
                    clientBuilder = new org.alfresco.client.api.content.CSClient.Builder();
                    break;
                case GOVERNANCE_SERVICES:
                    clientBuilder = new org.alfresco.client.api.governance.GSClient.Builder();
                    break;
                case PROCESS_SERVICES:
                    clientBuilder = new org.alfresco.client.api.process.PSClient.Builder();
                    break;
                case ACTIVITI:
                    clientBuilder = new org.alfresco.client.api.process.activiti.ActivitiClient.Builder();
                    break;
            }

            if (username != null)
            {
                clientBuilder.connect(localEndpoint, username, password).build();
            }
            else if (ticket != null)
            {
                clientBuilder.connectWithTicket(localEndpoint, ticket).build();
            }
            else if (token != null)
            {
                clientBuilder.connectWithToken(localEndpoint, token).build();
            }

            return clientBuilder;
        }

        // ////////////////////////////////////////////////////////////////////////////
        // BUILD
        // ///////////////////////////////////////////////////////////////////////////
        public AlfrescoClient build()
        {
            // Create Client
            mInstance = super.build();
            return mInstance;
        }
    }

    // ///////////////////////////////////////////////////////////////////////////
    // UTILS
    // ///////////////////////////////////////////////////////////////////////////
    public static class Utils
    {
        public static GsonBuilder getDefaultGsonBuilder()
        {
            return new GsonBuilder().setDateFormat(ISO8601Utils.DATE_ISO_FORMAT)
                    // Entry
                    .registerTypeAdapter(ActivityRepresentation.class, new EntryDeserializer<ActivityRepresentation>())
                    .registerTypeAdapter(CommentRepresentation.class, new EntryDeserializer<CommentRepresentation>())
                    .registerTypeAdapter(SiteMemberRepresentation.class,
                            new EntryDeserializer<SiteMemberRepresentation>())
                    .registerTypeAdapter(NodeRepresentation.class, new EntryDeserializer<NodeRepresentation>())
                    .registerTypeAdapter(DeletedNodeRepresentation.class,
                            new EntryDeserializer<DeletedNodeRepresentation>())
                    .registerTypeAdapter(PreferenceRepresentation.class,
                            new EntryDeserializer<PreferenceRepresentation>())
                    .registerTypeAdapter(RatingRepresentation.class, new EntryDeserializer<RatingRepresentation>())
                    .registerTypeAdapter(PersonRepresentation.class, new EntryDeserializer<PersonRepresentation>())
                    .registerTypeAdapter(SharedLinkRepresentation.class,
                            new EntryDeserializer<SharedLinkRepresentation>())
                    .registerTypeAdapter(RenditionRepresentation.class,
                            new EntryDeserializer<RenditionRepresentation>())
                    .registerTypeAdapter(SiteContainerRepresentation.class,
                            new EntryDeserializer<SiteContainerRepresentation>())
                    .registerTypeAdapter(SiteRoleRepresentation.class, new EntryDeserializer<SiteRoleRepresentation>())
                    .registerTypeAdapter(SiteMembershipRequestRepresentation.class,
                            new EntryDeserializer<SiteMembershipRequestRepresentation>())
                    .registerTypeAdapter(SiteRepresentation.class, new EntryDeserializer<SiteRepresentation>())
                    .registerTypeAdapter(TagRepresentation.class, new EntryDeserializer<TagRepresentation>())
                    .registerTypeAdapter(VersionRepresentation.class, new EntryDeserializer<VersionRepresentation>())
                    .registerTypeAdapter(FavoriteRepresentation.class, new FavoriteEntryDeserializer())

                    // Paging Results
                    .registerTypeAdapter(new TypeToken<ResultPaging<ActivityRepresentation>>()
                    {
                    }.getType(), new PagingDeserializer<>(ActivityRepresentation.class))
                    .registerTypeAdapter(new TypeToken<ResultPaging<CommentRepresentation>>()
                    {
                    }.getType(), new PagingDeserializer<>(CommentRepresentation.class))
                    .registerTypeAdapter(new TypeToken<ResultPaging<SiteMemberRepresentation>>()
                    {
                    }.getType(), new PagingDeserializer<>(SiteMemberRepresentation.class))
                    .registerTypeAdapter(new TypeToken<ResultPaging<SharedLinkRepresentation>>()
                    {
                    }.getType(), new PagingDeserializer<>(SharedLinkRepresentation.class))
                    .registerTypeAdapter(new TypeToken<ResultPaging<NodeRepresentation>>()
                    {
                    }.getType(), new PagingDeserializer<>(NodeRepresentation.class))
                    .registerTypeAdapter(new TypeToken<ResultPaging<DeletedNodeRepresentation>>()
                    {
                    }.getType(), new PagingDeserializer<>(DeletedNodeRepresentation.class))
                    .registerTypeAdapter(new TypeToken<ResultPaging<PreferenceRepresentation>>()
                    {
                    }.getType(), new PagingDeserializer<>(PreferenceRepresentation.class))
                    .registerTypeAdapter(new TypeToken<ResultPaging<FavoriteRepresentation>>()
                    {
                    }.getType(), new PagingDeserializer<>(FavoriteRepresentation.class))
                    .registerTypeAdapter(new TypeToken<ResultPaging<RatingRepresentation>>()
                    {
                    }.getType(), new PagingDeserializer<>(RatingRepresentation.class))
                    .registerTypeAdapter(new TypeToken<ResultPaging<RenditionRepresentation>>()
                    {
                    }.getType(), new PagingDeserializer<>(RenditionRepresentation.class))
                    .registerTypeAdapter(new TypeToken<ResultPaging<SiteContainerRepresentation>>()
                    {
                    }.getType(), new PagingDeserializer<>(SiteContainerRepresentation.class))
                    .registerTypeAdapter(new TypeToken<ResultPaging<SiteRoleRepresentation>>()
                    {
                    }.getType(), new PagingDeserializer<>(SiteRoleRepresentation.class))
                    .registerTypeAdapter(new TypeToken<ResultPaging<SiteMembershipRequestRepresentation>>()
                    {
                    }.getType(), new PagingDeserializer<>(SiteMembershipRequestRepresentation.class))
                    .registerTypeAdapter(new TypeToken<ResultPaging<SiteRepresentation>>()
                    {
                    }.getType(), new PagingDeserializer<>(SiteRepresentation.class))
                    .registerTypeAdapter(new TypeToken<ResultPaging<TagRepresentation>>()
                    {
                    }.getType(), new PagingDeserializer<>(TagRepresentation.class))
                    .registerTypeAdapter(new TypeToken<ResultPaging<VersionRepresentation>>()
                    {
                    }.getType(), new PagingDeserializer<>(VersionRepresentation.class))

                    // People API
                    .registerTypeAdapter(PersonRepresentation.class, new EntryDeserializer<PersonRepresentation>())
                    .registerTypeAdapter(new TypeToken<ResultPaging<PersonRepresentation>>()
                    {
                    }.getType(), new PagingDeserializer<>(PersonRepresentation.class))

                    // Groups API
                    .registerTypeAdapter(GroupRepresentation.class, new EntryDeserializer<GroupRepresentation>())
                    .registerTypeAdapter(GroupMemberRepresentation.class,
                            new EntryDeserializer<GroupMemberRepresentation>())

                    .registerTypeAdapter(new TypeToken<ResultPaging<GroupRepresentation>>()
                    {
                    }.getType(), new PagingDeserializer<>(GroupRepresentation.class))
                    .registerTypeAdapter(new TypeToken<ResultPaging<GroupMemberRepresentation>>()
                    {
                    }.getType(), new PagingDeserializer<>(GroupMemberRepresentation.class))

                    // Authentication
                    .registerTypeAdapter(TicketRepresentation.class, new EntryDeserializer<TicketRepresentation>())
                    .registerTypeAdapter(ValidTicketRepresentation.class,
                            new EntryDeserializer<ValidTicketRepresentation>())

                    // Discovery
                    .registerTypeAdapter(RepositoryInfoRepresentation.class,
                            new EntryDeserializer<RepositoryInfoRepresentation>())

                    // Search
                    .registerTypeAdapter(ResultNodeRepresentation.class,
                            new EntryDeserializer<ResultNodeRepresentation>())
                    .registerTypeAdapter(new TypeToken<ResultSetRepresentation<ResultNodeRepresentation>>()
                    {
                    }.getType(), new ResultSetPagingDeserializer<>(ResultNodeRepresentation.class))

                    // TODO Workflow

                    // TODO SWAGGER

            ;
        }
    }
    

    // ///////////////////////////////////////////////////////////////////////////
    // API REGISTRY
    // ///////////////////////////////////////////////////////////////////////////
   
    protected org.alfresco.client.api.content.CSClient csClient;

    protected org.alfresco.client.api.process.PSClient psClient;

    protected org.alfresco.client.api.governance.GSClient gsClient;

    protected org.alfresco.client.api.process.activiti.ActivitiClient aClient;


    public org.alfresco.client.api.content.ContentServicesRegistry getContentServices()
    {
        return csClient != null ? csClient.getApiRegistry() : null;
    }

    public org.alfresco.client.api.governance.GSAPIRegistry getGovernanceServices()
    {
        return gsClient != null ? gsClient.getApiRegistry() : null;
    }

    public org.alfresco.client.api.process.PSAPIRegistry getProcessServices()
    {
        return psClient != null ? psClient.getApiRegistry() : null;
    }

    public org.alfresco.client.api.process.activiti.ActivitiAPIRegistry getActivitiServices()
    {
        return aClient != null ? aClient.getApiRegistry() : null;
    }
    
}
