package com.alfresco.client.api.core.model.representation;

/**
 * Created by jpascal on 29/04/2017.
 */
public class FolderRepresentation extends NodeRepresentation
{

}
