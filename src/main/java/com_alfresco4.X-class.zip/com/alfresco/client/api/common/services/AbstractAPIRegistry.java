package com.alfresco.client.api.common.services;

/**
 * Created by jpascal on 30/04/2017.
 */
public class AbstractAPIRegistry implements APIRegistry
{
    protected RestClient restClient;

    public <T> T getAPI(final Class<T> service)
    {
        return restClient.retrofit.create(service);
    }
}
