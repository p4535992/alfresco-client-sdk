package com.alfresco.client.api.workflow;

import com.alfresco.client.api.common.constant.APIConstant;

/**
 * Created by jpascal on 05/10/2016.
 */
public interface WorkflowConstant extends APIConstant
{
    String WORKFLOW_PUBLIC_API_V1 = PREFIX_PUBLIC_API + "workflow/versions/1";
}
