package com.alfresco.client.api.discovery;

import com.alfresco.client.api.common.constant.APIConstant;

/**
 * Created by jpascal on 05/10/2016.
 */
public interface DiscoveryConstant extends APIConstant
{
    String DISCOVERY_PUBLIC_API_V1 = PREFIX_PUBLIC_API + "discovery/versions/1";
}
