package com.alfresco.client.api.authentication;

import okhttp3.OkHttpClient;

/**
 * Created by jpascal on 11/10/2016.
 */
// TODO Design it better to support Ticket Authentication
public class AuthenticationUtils
{

    public static String getTicket(String baseUrl)
    {
        OkHttpClient client = new OkHttpClient();
        return null;
    }
}
