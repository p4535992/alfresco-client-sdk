package com.alfresco.client.api.core;

import com.alfresco.client.api.common.constant.APIConstant;

/**
 * Created by jpascal on 05/10/2016.
 */
public interface CoreConstant extends APIConstant
{
    String CORE_PUBLIC_API_V1 = PREFIX_PUBLIC_API + "alfresco/versions/1";
}
