package org.alfresco.client.samples;

/**
 * Created by jpascal on 02/03/2016.
 */
public class SampleConstants
{

    public static final String ALFRESCO_URL = "http://";

    public static final String ALFRESCO_USER = "admin";

    public static final String ALFRESCO_PASSWORD = "admin";

}
